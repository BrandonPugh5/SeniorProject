﻿using UnityEngine;

public class GunBehavior : MonoBehaviour
{

    public GameObject bulletModel;
    public GameObject gun;
    private GameObject rightArm;
    private GameObject dialoguePanel;
    public float speed = 5.0f;

    public bool isHeldByPlayer;

    public static GunMode currentGunMode = GunMode.shrink;
    public enum GunMode
    {
        shrink,
        grow
    };

    private void Awake()
    {
        rightArm = GameObject.Find("RightArm");
        dialoguePanel = GameObject.Find("Canvas").transform.Find("DialoguePanel").gameObject;
    }
    private void Start()
    {

    }
    void Update()
    {

        if (rightArm.name != null 
            && GunInteract.isHeldByPlayer){
            isHeldByPlayer = true;
        }
        else
        {
            isHeldByPlayer = false;
        }

        Vector3 target = Camera.main.ScreenToWorldPoint(new Vector2(Input.mousePosition.x, Input.mousePosition.y));
        Vector3 direction = target - gun.transform.position;
        direction.Normalize();
        Quaternion rotation = Quaternion.Euler(0, 0, Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg);

        if (Input.GetMouseButtonDown(0) 
            && isHeldByPlayer
            && dialoguePanel != null
            && !dialoguePanel.activeInHierarchy)
        {
            GameObject projectile = Instantiate(bulletModel, gun.transform.position, rotation);
            currentGunMode = GunMode.shrink;
            projectile.GetComponent<Rigidbody2D>().velocity = direction * speed;
        }

        if(Input.GetMouseButtonDown(1) && isHeldByPlayer)
        {
            GameObject projectile = Instantiate(bulletModel, gun.transform.position, rotation);
            currentGunMode = GunMode.grow;
            projectile.GetComponent<Rigidbody2D>().velocity = direction * speed;
        }

    }


}







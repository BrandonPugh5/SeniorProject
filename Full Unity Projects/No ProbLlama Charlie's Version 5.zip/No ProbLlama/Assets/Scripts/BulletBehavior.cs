﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehavior : MonoBehaviour {
    float lifetime = 1.0f;
    
    void OnCollisionEnter2D(Collision2D objectHit)
    {
        string hitTag = objectHit.gameObject.tag;
        ShrinkAndGrow shrinkAndGrow = objectHit.gameObject.GetComponent<ShrinkAndGrow>();
        

        if (hitTag == "Shootable" 
            && GunBehavior.currentGunMode == GunBehavior.GunMode.shrink 
            && shrinkAndGrow.canShrink
            && !shrinkAndGrow.canOnlyGrow
            && shrinkAndGrow.maxShrinkHits > 0)
        {
            objectHit.transform.localScale *= shrinkAndGrow.shrinkScale;
            shrinkAndGrow.maxGrowHits++;
            shrinkAndGrow.maxShrinkHits--;
            shrinkAndGrow.canGrow = true;

            if (shrinkAndGrow.maxShrinkHits <= 0)
            {
                shrinkAndGrow.canShrink = false;
            }
        }
        else if (hitTag == "Shootable" 
            && GunBehavior.currentGunMode == GunBehavior.GunMode.grow
            && shrinkAndGrow.canGrow
            && !shrinkAndGrow.canOnlyShrink
            && shrinkAndGrow.maxGrowHits > 0)
        {
            objectHit.transform.localScale *= shrinkAndGrow.growScale;
            print(shrinkAndGrow.maxGrowHits);
            shrinkAndGrow.maxGrowHits--;
            print(shrinkAndGrow.maxGrowHits);
            shrinkAndGrow.maxShrinkHits++;
            shrinkAndGrow.canShrink = true;
            if(shrinkAndGrow.maxGrowHits <= 0)
            {
                shrinkAndGrow.canGrow = false;
            }
            
        }

        Destroy(gameObject);
    }
	
	// Update is called once per frame
	void Update () {

        lifetime -= 0.7f * Time.deltaTime;
        if (lifetime <= 0.0)
            Destroy(gameObject);

    }
}

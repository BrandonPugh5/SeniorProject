﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShrinkAndGrow : MonoBehaviour {


    public bool canShrink, canGrow;
    public int maxGrowHits, maxShrinkHits;
    public float growScale, shrinkScale;

}

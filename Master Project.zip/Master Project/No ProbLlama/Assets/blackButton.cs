﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blackButton : MonoBehaviour {
		public GateManager gm;
		void OnTriggerEnter2D (Collider2D other)
		{
			if (other.tag == "Player") 
			{
				gm.pressBlackButton();
				Destroy (this.gameObject);
			}
		}
	}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platformdestroy : MonoBehaviour {
    public float lifetime;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        lifetime -= 0.7f * Time.deltaTime;
        if (lifetime <= 0.0)
            Destroy(gameObject);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConstantHitButton : MonoBehaviour {

	public GateManager gm;

	void OnTriggerEnter2D (Collider2D other)
	{
		if(other.tag == "Shootable")
		{
			Debug.Log ("making contact with shootable");
			gm.CountWhiteGate ();
		}
	}

	void OnTriggerExit2D (Collider2D other)
	{
		if (other.tag == "Shootable") 
		{
			gm.uncountWhiteGate ();
		}
	}
}

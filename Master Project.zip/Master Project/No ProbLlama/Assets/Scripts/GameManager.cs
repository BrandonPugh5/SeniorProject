﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public static GameManager instance;
    [HideInInspector] public Transform currentSpawnPoint, originalSpawnPoint, secondarySpawnPoint;
    private Transform player;

    public Room currentRoom, startingRoom;
    int roomPositionX;
    int roomPositionY;
    public Dimension currentDimension;
    public Room[,] rooms;

    public bool finishedLoadingScene;
    public bool isChangingRoom = false;
    public RoomChangeDirection roomChangeDirection = RoomChangeDirection.UP;

    public enum Dimension
    {
        DEFAULT,
        CHICKEN,
        SWAN
    }

    public enum RoomChangeDirection
    {
        UP,
        DOWN,
        LEFT,
        RIGHT,
        RELOAD
    }

    private void Awake()
    {

        if(instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if(instance != this)
        {
            Destroy(gameObject);
            return;
        }
        LevelGeneration levelGeneration = GetComponent<LevelGeneration>();
        rooms = levelGeneration.rooms;
        originalSpawnPoint = GameObject.Find("Spawn Point").transform;
        secondarySpawnPoint = GameObject.Find("Secondary Spawn Point").transform;
        player = GameObject.Find("Player").transform;
        for (int x = 0; x < levelGeneration.halfGridSizeX * 2; x++)
        {
            for (int y = 0; y < levelGeneration.halfGridSizeY * 2; y++)
            {
                if (rooms[x, y] != null && rooms[x, y].type == Room.RoomType.STARTING_ROOM)
                {
                    startingRoom = rooms[x, y];
                    currentRoom = startingRoom;
                    roomPositionX = x;
                    roomPositionY = y;
                }
            }
        }
        currentRoom.currentSpawnPoint = originalSpawnPoint;
        EnableDoors();
        SetUpDoorScenes();
    }

   
    
	// Update is called once per frame
	void Update ()
	{
        originalSpawnPoint = GameObject.Find("Spawn Point").transform;
        secondarySpawnPoint = GameObject.Find("Secondary Spawn Point").transform;
        player = GameObject.Find("Player").transform;

        LevelGeneration levelGeneration = GetComponent<LevelGeneration>();
        rooms = levelGeneration.rooms;
        GameObject topDoor = GameObject.Find("Level Exits").transform.Find("Top Door").Find("Door Frame").Find("Door Entrance").gameObject;
        GameObject bottomDoor = GameObject.Find("Level Exits").transform.Find("Bottom Door").Find("Door Frame").Find("Door Entrance").gameObject;
        GameObject leftDoor = GameObject.Find("Level Exits").transform.Find("Left Door").Find("Door Frame").Find("Door Entrance").gameObject;
        GameObject rightDoor = GameObject.Find("Level Exits").transform.Find("Right Door").Find("Door Frame").Find("Door Entrance").gameObject;


        if (Input.GetButtonDown ("Reset")) {
			SceneLoader.sceneToLoad = SceneManager.GetActiveScene ().name;
			SceneLoader.loadScene = true;
		}
        if (Input.GetKeyDown(KeyCode.I) && currentRoom.isComplete && topDoor.activeInHierarchy)
        {
            player.transform.position = topDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.K) && currentRoom.isComplete && bottomDoor.activeInHierarchy)
        {
            player.transform.position = bottomDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.J) && currentRoom.isComplete && leftDoor.activeInHierarchy)
        {
            player.transform.position = leftDoor.transform.position;
        }

        if (Input.GetKeyDown(KeyCode.L) && currentRoom.isComplete && rightDoor.activeInHierarchy)
        {
            player.transform.position = rightDoor.transform.position;
        }


        if (finishedLoadingScene)
        {
            finishedLoadingScene = false;
            EnableDoors();
            SetUpDoorScenes();
            player.transform.position = currentRoom.isComplete ? secondarySpawnPoint.position : originalSpawnPoint.position;
        }

        if (isChangingRoom)
        {
            isChangingRoom = false;
            SetUpDoorScenes();
            SetSpawnPoints();

        }

        if (currentRoom.isComplete)
        {
            currentRoom.currentSpawnPoint = secondarySpawnPoint;
        }
	}

    void SetUpDoorScenes()
    {
        switch (roomChangeDirection)
        {
            case RoomChangeDirection.UP:
                print("room up");
                currentRoom = rooms[roomPositionX, roomPositionY + 1];
                break;
            case RoomChangeDirection.DOWN:
                currentRoom = rooms[roomPositionX, roomPositionY - 1];
                print("room down");
                break;
            case RoomChangeDirection.LEFT:
                currentRoom = rooms[roomPositionX - 1, roomPositionY];
                print("room left");
                break;
            case RoomChangeDirection.RIGHT:
                print("room right");
                currentRoom = rooms[roomPositionX + 1, roomPositionY];
                break;
            case RoomChangeDirection.RELOAD:
                break;
        }

        //GameObject.Find("Top Door").transform.Find("Door Frame").Find("Door Entrance").GetComponent<LoadTrigger>().sceneToLoad = currentRoom.topDoorScene;
        GameObject.Find("Level Exits").transform.Find("Top Door").transform.Find("Door Frame").Find("Door Entrance").GetComponent<LoadTrigger>().sceneToLoad = currentRoom.topDoorScene;
        GameObject.Find("Level Exits").transform.Find("Bottom Door").transform.Find("Door Frame").Find("Door Entrance").GetComponent<LoadTrigger>().sceneToLoad = currentRoom.bottomDoorScene;
        GameObject.Find("Level Exits").transform.Find("Left Door").transform.Find("Door Frame").Find("Door Entrance").GetComponent<LoadTrigger>().sceneToLoad = currentRoom.leftDoorScene;
        GameObject.Find("Level Exits").transform.Find("Right Door").transform.Find("Door Frame").Find("Door Entrance").GetComponent<LoadTrigger>().sceneToLoad = currentRoom.rightDoorScene;
    }

    void EnableDoors()
    {
        if (currentRoom.doorTop)
        {
            GameObject.Find("Level Exits").transform.Find("Top Door").gameObject.SetActive(true);
        }
        if (currentRoom.doorBot)
        {
            GameObject.Find("Level Exits").transform.Find("Bottom Door").gameObject.SetActive(true);
        }
        if (currentRoom.doorLeft)
        {
            GameObject.Find("Level Exits").transform.Find("Left Door").gameObject.SetActive(true);
        }
        if (currentRoom.doorRight)
        {
            GameObject.Find("Level Exits").transform.Find("Right Door").gameObject.SetActive(true);
        }
    }

    void SetSpawnPoints()
    {
        originalSpawnPoint = GameObject.Find("Spawn Point").transform;
        secondarySpawnPoint = GameObject.Find("Secondary Spawn Point").transform;
        currentRoom.currentSpawnPoint = originalSpawnPoint;
    }

}

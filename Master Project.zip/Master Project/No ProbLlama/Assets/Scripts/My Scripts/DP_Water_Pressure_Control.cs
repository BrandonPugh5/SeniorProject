﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DP_Water_Pressure_Control : MonoBehaviour
{
    public enum AXIS { X, Y, None };
    public AXIS currentaxis = AXIS.None;
    public GameObject generator;
    private ParticleGenerator script;
    bool present;
    // Use this for initialization
    void Start()
    {
        script = generator.GetComponent<ParticleGenerator>();
        present = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
            present = true;
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
            present = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (present)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                if (checkAxis(currentaxis))
                {
                    script.particleForce.x = script.particleForce.x + 5000f;
                }
                else
                {
                    script.particleForce.y = script.particleForce.y + 5000f;
                }
            }
            else if (Input.GetKeyDown(KeyCode.Q))
            {
                if (checkAxis(currentaxis))
                {
                    script.particleForce.x = script.particleForce.x - 5000f;
                }
                else
                {
                    script.particleForce.y = script.particleForce.y - 5000f;
                }
            }
        }

    }

    public bool checkAxis(AXIS newaxis)
    {
        switch (newaxis)
        {
            case AXIS.X:
                return true;
            case AXIS.Y:
                return false;
        }
        return true;
    }
}


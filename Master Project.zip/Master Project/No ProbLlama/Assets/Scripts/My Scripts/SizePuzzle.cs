﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SizePuzzle : MonoBehaviour {
    public GameObject obj1; // largest object
    public GameObject obj2; // smaller than 1 but larger than 2
    public GameObject obj3; // smaller than 1 and 2 but larger than 4
    public GameObject obj4; // smallest object
    public GameObject gate; // object blocking progress
    float sizeObj1;
    float sizeObj2;
    float sizeObj3;
    float sizeObj4;
    bool present;

    // Use this for initialization
    void Start () {

        GetSizes();
    }



    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag.Equals("Player"))
        {
            present = false;
            gameObject.GetComponent<Renderer>().material.color = Color.white;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag.Equals("Player"))
        {
            present = true;
            gameObject.GetComponent<Renderer>().material.color = Color.blue;
        }

    }

    // Update is called once per frame
    void Update () {
        if (Input.GetKeyDown(KeyCode.Equals))
        {
            GetSizes();

            if (sizeObj1 > sizeObj2 && sizeObj2 > sizeObj3 && sizeObj3 > sizeObj4)
            {
                Destroy(gate); // in this case im choosing to destroy the gate in order to remove it as an obstacle
            }
        }
    }

    // multiply the size of the bound on each axis and multiply by its scale to get the current size of the object
    public void GetSizes()
    {
        sizeObj1 = (obj1.GetComponent<MeshRenderer>().bounds.size.x * obj1.transform.localScale.x) 
                 + (obj1.GetComponent<MeshRenderer>().bounds.size.y * obj1.transform.localScale.y);

        sizeObj2 = (obj2.GetComponent<MeshRenderer>().bounds.size.x * obj2.transform.localScale.x) 
                 + (obj2.GetComponent<MeshRenderer>().bounds.size.y * obj2.transform.localScale.y);

        sizeObj3 = (obj3.GetComponent<MeshRenderer>().bounds.size.x * obj3.transform.localScale.x) 
                 + (obj3.GetComponent<MeshRenderer>().bounds.size.y * obj3.transform.localScale.y);

        sizeObj4 = (obj4.GetComponent<MeshRenderer>().bounds.size.x * obj4.transform.localScale.x) 
                 + (obj4.GetComponent<MeshRenderer>().bounds.size.y * obj4.transform.localScale.y);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrangeButton : MonoBehaviour {

		public GateManager gm;
		void OnTriggerEnter2D (Collider2D other)
		{
		if (other.tag == "Object" || other.tag == "Shootable") 
			{
			    gm.OpenOrangeGate ();
				Destroy (this.gameObject);
				Destroy (other.gameObject);
			}
		if (other.gameObject.tag == "Player") {
			gm.OpenOrangeGate ();
			Destroy (this.gameObject);
		}
		}

	}

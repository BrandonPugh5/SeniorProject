﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Room {

	public Vector2 gridPos;
    public static bool startingRoomExists;
	public RoomType type;
	public bool doorTop, doorBot, doorLeft, doorRight;
    public string topDoorScene, bottomDoorScene, leftDoorScene, rightDoorScene;
    public string sceneForThisRoom;
    public Transform currentSpawnPoint;
    public bool isComplete;

    public enum RoomType
    {
        STARTING_ROOM,
        RANDOM_PUZZLE,
        BOSS_ROOM
    }

	public Room(Vector2 gridPos, RoomType type){
		this.gridPos = gridPos;
		this.type = type;
	}
}

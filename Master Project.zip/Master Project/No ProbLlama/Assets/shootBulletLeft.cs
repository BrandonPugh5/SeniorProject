﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shootBulletLeft : MonoBehaviour {

	public float speed;

	void Start ()
	{
		transform.Rotate (0, 0, 90);
		GetComponent<Rigidbody2D> ().velocity = transform.up * speed;
	}
	

}
